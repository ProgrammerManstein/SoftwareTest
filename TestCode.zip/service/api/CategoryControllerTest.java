package me.zhulin.shopapi.api;

import me.zhulin.shopapi.ShopApiApplication;
import me.zhulin.shopapi.entity.Cart;
import me.zhulin.shopapi.entity.ProductInfo;
import me.zhulin.shopapi.entity.User;
import me.zhulin.shopapi.form.ItemForm;
import me.zhulin.shopapi.repository.OrderRepository;
import me.zhulin.shopapi.service.CartService;
import me.zhulin.shopapi.service.CategoryService;
import me.zhulin.shopapi.service.UserService;
import me.zhulin.shopapi.vo.response.CategoryPage;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;

import javax.management.remote.JMXPrincipal;
import java.security.Principal;

import static org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = ShopApiApplication.class)
class CategoryControllerTest {

    @Autowired
    CategoryController categoryController;

    @Test
    void showOneTest() {
        Assertions.assertEquals("Books", categoryController.showOne(0,1,3).getCategory());
    }
}