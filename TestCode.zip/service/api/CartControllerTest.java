package me.zhulin.shopapi.api;

import me.zhulin.shopapi.ShopApiApplication;
import me.zhulin.shopapi.entity.Cart;
import me.zhulin.shopapi.entity.ProductInfo;
import me.zhulin.shopapi.entity.User;
import me.zhulin.shopapi.form.ItemForm;
import me.zhulin.shopapi.repository.OrderRepository;
import me.zhulin.shopapi.service.CartService;
import me.zhulin.shopapi.service.CategoryService;
import me.zhulin.shopapi.service.UserService;
import me.zhulin.shopapi.vo.response.CategoryPage;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import javax.management.remote.JMXPrincipal;
import java.security.Principal;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = ShopApiApplication.class)

/**
 * Created By Zhu Lin on 1/2/2019.
 */
public class CartControllerTest {
    public Cart cart;
    @Autowired
    CartController cartController;

    @Autowired
    UserService userService;

    @Autowired
    CartService cartService;

    @Mock
    Principal principal;

    @Mock
    ItemForm form;

    @BeforeEach
    public void getStart(){
        cart=new Cart();
        cart.setCartId(2147483641);
    }

    @Test
    public void getCartTest() {
        Mockito.when(principal.getName()).thenReturn("customer1@email.com");
        Assertions.assertEquals(cart.getCartId(), cartController.getCart(principal).getCartId());
    }

    @Test
    public void addToCartTest(){
        Mockito.when(form.getProductId()).thenReturn("B0003");
        Mockito.when(principal.getName()).thenReturn("customer1@email.com");
        Assertions.assertTrue(cartController.addToCart(form,principal));
        Mockito.when(form.getProductId()).thenReturn("");
        Assertions.assertFalse(cartController.addToCart(form,principal));
    }

    @Test
    @Transactional
    public void modifyItemTest(){
        Mockito.when(principal.getName()).thenReturn("customer1@email.com");
        Mockito.when(form.getProductId()).thenReturn("B0001");
        cartController.addToCart(form, principal);
        Assertions.assertEquals(2, cartController.modifyItem("B0001",2,principal).getCount());
    }

    @Test
    @Transactional
    public void deleteItemItemTest() throws InterruptedException {
        Mockito.when(principal.getName()).thenReturn("customer1@email.com");
        cartController.deleteItem("B0001",principal);
        User user=userService.findOne(principal.getName());
        Assertions.assertFalse(user.getCart().toString().contains("B0001"));
    }

    @Transactional
    @Test
    public void ResponseEntityTest(){
        Mockito.when(principal.getName()).thenReturn("customer1@email.com");
        Assertions.assertEquals(ResponseEntity.ok(null), cartController.checkout(principal));
    }
}
