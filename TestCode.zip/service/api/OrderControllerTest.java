package me.zhulin.shopapi.api;

import me.zhulin.shopapi.ShopApiApplication;
import me.zhulin.shopapi.entity.Cart;
import me.zhulin.shopapi.entity.OrderMain;
import me.zhulin.shopapi.entity.ProductInfo;
import me.zhulin.shopapi.entity.User;
import me.zhulin.shopapi.form.ItemForm;
import me.zhulin.shopapi.repository.OrderRepository;
import me.zhulin.shopapi.service.CartService;
import me.zhulin.shopapi.service.CategoryService;
import me.zhulin.shopapi.service.UserService;
import me.zhulin.shopapi.vo.response.CategoryPage;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.transaction.annotation.Transactional;

import javax.management.remote.JMXPrincipal;
import java.security.Principal;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = ShopApiApplication.class)
class OrderControllerTest {

    @Autowired
    OrderController orderController;

    @Mock
    Authentication authentication;

    Collection<? extends GrantedAuthority> collection1;
    Collection<? extends GrantedAuthority> collection2;

    @BeforeEach
    public void setUp(){
        collection1=List.of(new SimpleGrantedAuthority("ROLE_CUSTOMER"));
        collection2=List.of();
    }

    @Test
    void orderListTest() {
        Mockito.doReturn(collection1).when(authentication).getAuthorities();
        Mockito.when(authentication.getName()).thenReturn("customer1@email.com");
        Assertions.assertEquals(2147483648l, orderController.orderList(1,10,authentication).get().findFirst().get().getOrderId());
        Mockito.doReturn(collection2).when(authentication).getAuthorities();
        Assertions.assertEquals(2147483649l, orderController.orderList(1,10,authentication).get().findFirst().get().getOrderId());
    }

    @Test
    void cancelTest(){
        Mockito.doReturn(collection1).when(authentication).getAuthorities();
        Mockito.when(authentication.getName()).thenReturn("customer2@email.com");
        Assertions.assertEquals(200,orderController.cancel(2147483649l,authentication).getStatusCodeValue());
        Mockito.when(authentication.getName()).thenReturn("customer1@email.com");
        Assertions.assertEquals(401,orderController.cancel(2147483649l,authentication).getStatusCodeValue());
    }

    @Test
    void finishTest(){
        Mockito.doReturn(collection1).when(authentication).getAuthorities();
        Assertions.assertEquals(401,orderController.finish(2147483649l,authentication).getStatusCodeValue());
        Mockito.doReturn(collection2).when(authentication).getAuthorities();
        Assertions.assertEquals(200,orderController.finish(2147483649l,authentication).getStatusCodeValue());
    }

    @Test
    void showTest(){
        Mockito.doReturn(collection1).when(authentication).getAuthorities();
        Mockito.when(authentication.getName()).thenReturn("customer1@email.com");
        Assertions.assertEquals(401,orderController.show(2147483649l,authentication).getStatusCodeValue());
        Mockito.doReturn(collection2).when(authentication).getAuthorities();
        Assertions.assertEquals(200,orderController.show(2147483649l,authentication).getStatusCodeValue());
    }
}