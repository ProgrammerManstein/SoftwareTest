package me.zhulin.shopapi.controller;


import me.zhulin.shopapi.ShopApiApplication;
import me.zhulin.shopapi.api.ProductController;
import me.zhulin.shopapi.entity.ProductInfo;
import me.zhulin.shopapi.service.ProductService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.validation.BindingResult;

import javax.transaction.Transactional;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(classes = ShopApiApplication.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class ProductControllerTest {
    @Autowired
    ProductController productController;

    private ProductInfo productInfo;

    private final String testProductId= "B0001";

    @Autowired
    private ProductService productService;

    @Mock
    private BindingResult bindingResult;

    @Before
    public void setUp(){
        productInfo = new ProductInfo();
        productInfo.setProductId("1");
        productInfo.setCategoryType(0);
        productInfo.setProductStock(10);
        productInfo.setProductStatus(1);
        productInfo.setProductName("test");
        productInfo.setProductPrice(BigDecimal.valueOf(2));
    }

    @Test
    public void findAllTest() {
        Page<ProductInfo> page = productController.findAll(1,9);
        assertEquals("B0001", page.get().findFirst().get().getProductId());
    }


    @Transactional
    @Test
    public void showOneTest() {
        assertEquals(testProductId,productController.showOne(testProductId).getProductId());
    }

    @Transactional
    @Test
    public void createTest() {
        var responseEntity = productController.create(productInfo,bindingResult);
        assertEquals(responseEntity,ResponseEntity.ok(productInfo));

        productInfo.setProductId(testProductId);
        Mockito.when(bindingResult.hasErrors()).thenReturn(true);
        var responseEntityFailed = productController.create(productInfo,bindingResult);
        assertEquals(responseEntityFailed.getStatusCode().toString(),"400 BAD_REQUEST");
    }
    @Transactional
    @Test
    public void editTest() {
        Mockito.when(bindingResult.hasErrors()).thenReturn(true);
        var responseEntityFailed = productController.create(productInfo,bindingResult);
        assertEquals(responseEntityFailed.getStatusCode().toString(),"400 BAD_REQUEST");

        productInfo.setProductId(testProductId);
        Mockito.when(bindingResult.hasErrors()).thenReturn(false);
        assertEquals(ResponseEntity.ok(productService.update(productInfo)),
                productController.edit(productInfo.getProductId(),productInfo,bindingResult));
    }
    @Transactional
    @Test
    public void deleteTest() {
        assertEquals(ResponseEntity.ok().build(),productController.delete(testProductId));
    }

}
