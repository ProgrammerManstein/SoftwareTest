package me.zhulin.shopapi.repository;

import me.zhulin.shopapi.entity.OrderMain;
import me.zhulin.shopapi.entity.ProductInOrder;
import me.zhulin.shopapi.entity.ProductInfo;
import me.zhulin.shopapi.entity.User;
import me.zhulin.shopapi.enums.OrderStatusEnum;
import me.zhulin.shopapi.exception.MyException;
import me.zhulin.shopapi.repository.OrderRepository;
import me.zhulin.shopapi.repository.ProductInfoRepository;
import me.zhulin.shopapi.service.OrderService;
import me.zhulin.shopapi.service.ProductService;
import me.zhulin.shopapi.service.impl.OrderServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RepositoryTest {
    Page page;
    OrderMain orderMain;
    User user;
    @Mock
    private OrderRepository orderRepository;
    @Mock
    private UserRepository userRepository;
    @InjectMocks
    private ProductServiceImpl productService;
    @InjectMocks
    private OrderServiceImpl orderService;

    private OrderMain orderMain;

    private Page<OrderMain> page;

    @Mock
    private ProductCategoryRepository productCategoryRepository;

    @InjectMocks
    private CategoryServiceImpl categoryService;
    @Mock
    private ProductInfoRepository productInfoRepository;

    private ProductInfo productInfo;

    @Before
    public void setUp(){
        orderMain = new OrderMain();
        orderMain.setOrderId(1L);
        orderMain.setOrderStatus(OrderStatusEnum.NEW.getCode());
        orderMain.setBuyerPhone("139");

        user=new User();
        user.setPassword("password");
        user.setEmail("email@email.com");
        user.setName("Name");
        user.setPhone("Phone Test");
        user.setAddress("Address Test");
        page=new PageImpl<>(List.of(orderMain));
        ProductInOrder productInOrder = new ProductInOrder();
        productInOrder.setProductId("1");
        productInOrder.setCount(10);

        Set<ProductInOrder> set = new HashSet<>();
        set.add(productInOrder);

        orderMain.setProducts(set);

        ProductInfo productInfo = new ProductInfo();
        productInfo.setProductId("1");
        productInfo.setProductStatus(1);
        productInfo.setProductStock(10);
        cart.setProducts(set);
        user.setCart(cart);
        page = new PageImpl<>(List.of(orderMain));
    }

    @Test
    public void findByOrderIdTest() {
        orderMain.setOrderId(1l);
        orderRepository.save(orderMain);
        Mockito.when(orderRepository.findByOrderId(1l)).thenReturn(orderMain);
        orderRepository.findByOrderId(1l);
        Mockito.verify(orderRepository, Mockito.times(1)).findByOrderId(1l);
        assertThat(orderRepository.findByOrderId(1l),is(orderMain));
    }

    @Test
    public void findAllByOrderStatusOrderByCreateTimeDescTest() {
        orderMain.setOrderStatus(1);
        orderRepository.save(orderMain);
        Mockito.when(orderRepository.findAllByOrderStatusOrderByCreateTimeDesc(1,null)).thenReturn(page);
        orderRepository.findAllByOrderStatusOrderByCreateTimeDesc(1,null);
        Mockito.verify(orderRepository, Mockito.times(1)).findAllByOrderStatusOrderByCreateTimeDesc(1,null);
        assertThat(orderRepository.findAllByOrderStatusOrderByCreateTimeDesc(1,null).get().findFirst().get(),is(orderMain));
    }

    @Test
    public void findAllByBuyerEmailOrderByOrderStatusAscCreateTimeDescTest() {
        orderMain.setBuyerEmail("123@xx.com");
        orderRepository.save(orderMain);
        Mockito.when(orderRepository.findAllByBuyerEmailOrderByOrderStatusAscCreateTimeDesc("123@xx.com",null)).thenReturn(page);
        orderRepository.findAllByBuyerEmailOrderByOrderStatusAscCreateTimeDesc("123@xx.com",null);
        Mockito.verify(orderRepository, Mockito.times(1)).findAllByBuyerEmailOrderByOrderStatusAscCreateTimeDesc("123@xx.com",null);
        assertThat(orderRepository.findAllByBuyerEmailOrderByOrderStatusAscCreateTimeDesc("123@xx.com",null).get().findFirst().get(),is(orderMain));
    }
    @Test
    public void findByEmail() {
        user.setEmail("123@abc.com");
        userRepository.save(user);
        Mockito.when(userRepository.findByEmail("123@abc.com")).thenReturn(user);
        userRepository.findByEmail("123@abc.com");
        Mockito.verify(userRepository, Mockito.times(1)).findByEmail("123@abc.com");
        assertThat(userRepository.findByEmail("123@abc.com"),is(user));
    }
    @Test
    public void findAllByOrderByOrderStatusAscCreateTimeDescTest(){
        orderRepository.save(orderMain);
        Mockito.when(orderRepository.findAllByOrderByOrderStatusAscCreateTimeDesc(null)).thenReturn(page);
        orderRepository.findAllByOrderByOrderStatusAscCreateTimeDesc(null);
        Mockito.verify(orderRepository,Mockito.times(1)).findAllByOrderByOrderStatusAscCreateTimeDesc(null);
        assertEquals(orderRepository.findAllByOrderByOrderStatusAscCreateTimeDesc(null).get().findFirst().get(),orderMain);
    }

    @Test
    public void findAllByBuyerPhoneOrderByOrderStatusAscCreateTimeDescTest(){
        orderRepository.save(orderMain);
        Mockito.when(orderRepository.findAllByBuyerPhoneOrderByOrderStatusAscCreateTimeDesc(orderMain.getBuyerPhone(),null)).thenReturn(page);
        orderRepository.findAllByBuyerPhoneOrderByOrderStatusAscCreateTimeDesc(orderMain.getBuyerPhone(),null);
        Mockito.verify(orderRepository,Mockito.times(1)).findAllByBuyerPhoneOrderByOrderStatusAscCreateTimeDesc(orderMain.getBuyerPhone(),null);
        assertEquals(orderRepository.findAllByBuyerPhoneOrderByOrderStatusAscCreateTimeDesc(orderMain.getBuyerPhone(),null).get().findFirst().get(),orderMain);
    }


    @Test
    public void findByCategoryTypeInOrderByCategoryTypeAsc(){
        ProductCategory productCategory = new ProductCategory();
        productCategory.setCategoryType(1);

        productCategoryRepository.save(productCategory);
        Mockito.when(productCategoryRepository.findByCategoryTypeInOrderByCategoryTypeAsc(List.of(productCategory.getCategoryType()))).thenReturn(List.of(productCategory));

        productCategoryRepository.findByCategoryTypeInOrderByCategoryTypeAsc(List.of(productCategory.getCategoryType()));

        Mockito.verify(productCategoryRepository, Mockito.times(1)).findByCategoryTypeInOrderByCategoryTypeAsc(List.of(productCategory.getCategoryType()));
        assertEquals(productCategoryRepository.findByCategoryTypeInOrderByCategoryTypeAsc(List.of(productCategory.getCategoryType())),List.of(productCategory));
    }

    @Test
    public void findByCategoryTypeTest() {
        ProductCategory productCategory = new ProductCategory();
        productCategory.setCategoryId(1);

        Mockito.when(productCategoryRepository.findByCategoryType(productCategory.getCategoryId())).thenReturn(productCategory);

        categoryService.findByCategoryType(productCategory.getCategoryId());

        Mockito.verify(productCategoryRepository, Mockito.times(1)).findByCategoryType(productCategory.getCategoryId());
        assertEquals(productCategoryRepository.findByCategoryType(productCategory.getCategoryId()),productCategory);

    }

    @Test
    public void findByProductIdTest(){
        productInfoRepository.save(productInfo);
        Mockito.when(productInfoRepository.findByProductId(productInfo.getProductId())).thenReturn(productInfo);
        productInfoRepository.findByProductId(productInfo.getProductId());
        Mockito.verify(productInfoRepository,Mockito.times(1)).findByProductId(productInfo.getProductId());
        assertEquals(productInfoRepository.findByProductId(productInfo.getProductId()),productInfo);
    }
    @Test
    public void findByProductIdTest(){
        productInfoRepository.save(productInfo);
        when(productInfoRepository.findByProductId(productInfo.getProductId())).thenReturn(productInfo);
        productInfoRepository.findByProductId(productInfo.getProductId());
        Mockito.verify(productInfoRepository,times(1)).findByProductId(productInfo.getProductId());
        assertEquals(productInfoRepository.findByProductId(productInfo.getProductId()),productInfo);
    }
    
    @Test
    public void findAllByRole(){
        userRepository.save(user);
        Mockito.when(userRepository.findAllByRole(user.getRole())).thenReturn(List.of(user));
        userRepository.findAllByRole(user.getRole());
        Mockito.verify(userRepository,Mockito.times(1)).findAllByRole(user.getRole());
        assertEquals(userRepository.findAllByRole(user.getRole()),List.of(user));
    }
}
